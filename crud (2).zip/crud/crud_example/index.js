const mysql = require('mysql');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'priya@777',
    database: 'crud_example'
});

// Connect to MySQL
db.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL');
});

// Create a new course
function createCourse(courseData) {
    db.query('INSERT INTO courses SET ?', courseData, (err, result) => {
        if (err) {
            console.error('Error creating course:', err);
            return;
        }
        console.log('Course created successfully:', result.insertId);
    });
}

// Read all courses
function getAllCourses() {
    db.query('SELECT * FROM courses', (err, results) => {
        if (err) {
            console.error('Error fetching courses:', err);
            return;
        }
        console.log('All courses:', results);
    });
}

// Update a course by ID
function updateCourse(courseId, newData) {
    db.query('UPDATE courses SET ? WHERE id = ?', [newData, courseId], (err, result) => {
        if (err) {
            console.error('Error updating course:', err);
            return;
        }
        console.log('Course updated successfully:', result.changedRows);
    });
}

// Delete a course by ID
function deleteCourse(courseId) {
    db.query('DELETE FROM courses WHERE id = ?', courseId, (err, result) => {
        if (err) {
            console.error('Error deleting course:', err);
            return;
        }
        console.log('Course deleted successfully:', result.affectedRows);
    });
}

// Example usage:
//createCourse({ name: 'Mathematics', instructor: 'John Doe', duration: '3 months' });

// Uncomment the lines below to test other CRUD operations
getAllCourses();
// updateCourse(1, { name: 'Physics', instructor: 'Jane Doe', duration: '4 months' });
//deleteCourse(4);

// Close the connection after performing operations
db.end();
